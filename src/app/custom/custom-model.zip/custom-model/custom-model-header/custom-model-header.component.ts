import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'custom-model-header',
  templateUrl: './custom-model-header.component.html',
  styleUrls: ['./custom-model-header.component.scss']
})
export class CustomModelHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
