import { OpenPopUpDirective } from './open-pop-up.directive';

describe('OpenPopUpDirective', () => {
  it('should create an instance', () => {
    const directive = new OpenPopUpDirective();
    expect(directive).toBeTruthy();
  });
});
